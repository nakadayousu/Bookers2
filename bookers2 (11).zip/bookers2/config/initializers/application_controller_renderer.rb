# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'aa8b9c3ed6629ce614dc69a08416d443208d8bface178ee256936c5070a766e92b0e0511b620772f6ddb7aa7e2b8a64353d61e1d79fa9dd29554638b720297c4'
